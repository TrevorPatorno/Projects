public class bag extends solid {
	
	bag(String m, String c, boolean f, String o, int v){
		super(m, c, f, o, v);
		
	}


}
