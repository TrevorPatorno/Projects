public class box extends solid{
	
	box(String m, String c, boolean f, String o, int v){
		super(m, c, f, o, v);
		
	}

}
