public class cup extends liquid{
	
	cup(String m, String c, boolean f, String o, int v){
		super(m, c, f, o, v);
	}

}
